const { S3Client, GetObjectCommand, PutObjectCommand, HeadObjectCommand } = require("@aws-sdk/client-s3");
const sharp = require('sharp');

const s3 = new S3Client({ region: "eu-north-1" });

exports.handler = async (event) => {
  const bucket = event.Records[0].s3.bucket.name;
  const key = event.Records[0].s3.object.key;
  const maxSize = 1 * 1024 * 1024; // 1 MB

  try {
    // Verificar se a imagem já foi otimizada (evitar loop infinito)
    const metadataParams = new HeadObjectCommand({ Bucket: bucket, Key: key });
    const metadata = await s3.send(metadataParams);

    if (metadata.Metadata?.optimized === 'true') {
      console.log(`Imagem ${key} já foi otimizada, ignorando.`);
      return { status: 'Imagem já otimizada, ignorada' };
    }

    // Baixar a imagem do S3
    const params = new GetObjectCommand({ Bucket: bucket, Key: key });
    const { Body } = await s3.send(params);

    let quality = 90;
    let resizedImage = sharp(await Body.transformToByteArray())
      .rotate()
      .resize({ width: 1920, fit: 'inside' });

    // Compressão até atingir < 1 MB
    let outputBuffer;
    do {
      outputBuffer = await resizedImage.jpeg({ quality: quality }).toBuffer();
      quality -= 10;
    } while (outputBuffer.length > maxSize && quality > 20);

    // Sobrescrever a imagem original no S3 com metadado "optimized: true"
    const putParams = new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: outputBuffer,
      ContentType: 'image/jpeg',
      Metadata: { optimized: 'true' }, // Marca a imagem como otimizada
    });

    await s3.send(putParams);

    return { status: 'Imagem otimizada e sobrescrita com sucesso', key };
  } catch (error) {
    console.error("Erro ao processar a imagem:", error);
    return { status: 'Erro ao processar a imagem', error: error.message };
  }
};
